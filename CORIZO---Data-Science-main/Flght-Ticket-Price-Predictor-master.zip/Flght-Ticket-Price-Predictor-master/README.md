# Flght-Ticket-Price-Predictor
This repo contains FTPP project on data science.
