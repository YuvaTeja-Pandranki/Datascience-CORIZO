# Automaic-Spammer
I  wrote a python script to spam my niece with a lot of whatsapp messages.
