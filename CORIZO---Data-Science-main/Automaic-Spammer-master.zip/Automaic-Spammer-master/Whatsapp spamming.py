#!/usr/bin/env python
# coding: utf-8

# In[2]:


get_ipython().system('pip install pyautogui')
get_ipython().system('pip install webbrowser')


# In[1]:


import pyautogui
import webbrowser as wb
import time


# In[3]:


#wb.open("web.whatsapp.com")
time.sleep(10)
for i in range(3000):
    pyautogui.press("W")
    pyautogui.press("h") 
    pyautogui.press("a")
    pyautogui.press("t")
    pyautogui.press("space")
    pyautogui.press("i")
    pyautogui.press("s")
    pyautogui.press("space")
    pyautogui.press("t")
    pyautogui.press("h")
    pyautogui.press("a")
    pyautogui.press("t")
    pyautogui.press("space")
    pyautogui.press("v")
    pyautogui.press("i")
    pyautogui.press("d")
    pyautogui.press("e")
    pyautogui.press("o")
    pyautogui.press("space")
    pyautogui.press("y")
    pyautogui.press("o")
    pyautogui.press("u")
    pyautogui.press("space")
    pyautogui.press("s")
    pyautogui.press("e")
    pyautogui.press("n")
    pyautogui.press("t")
    pyautogui.press("space")
    pyautogui.press("m")
    pyautogui.press("e")
    pyautogui.press("?")
    pyautogui.press("enter")


# In[ ]:




